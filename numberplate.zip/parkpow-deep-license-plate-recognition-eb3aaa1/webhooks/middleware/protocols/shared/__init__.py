"""Shared utilities for protocols."""
