"""Webhook protocols for middleware."""
