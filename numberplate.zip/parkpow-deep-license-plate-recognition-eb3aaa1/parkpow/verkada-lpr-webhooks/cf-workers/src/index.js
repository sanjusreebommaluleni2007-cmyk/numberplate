import { Buffer } from "node:buffer";
import Rollbar from "@triptech/cloudflare-worker-rollbar";

class Error429 extends Error {
  constructor({ message, response }) {
    super(message);
    this.name = "429Error";
    this.data = response;
  }
}

class Error5xx extends Error {
  constructor({ message, response }) {
    super(message);
    this.name = "5xxError";
    this.data = response;
  }
}

const wait = (delay) => new Promise((resolve) => setTimeout(resolve, delay));

const fetchWithRetry = (url, init, tries = 3) =>
  fetch(url, init)
    .then((response) => {
      if (response.ok) {
        return response;
      } else {
        // 1. throw a new exception
        if (response.status === 429) throw new Error429("Rate Limited", response);
        if (response.status >= 500 && response.status <= 599)
          throw new Error5xx(`Server Error - ${response.status}`, response);
        // 2. reject instead of throw, preferred
        const errorMessage = `Unexpected Response: ${response.status} from ${url}`;
        return Promise.reject(new Error(errorMessage));
      }
    })
    .catch((error) => {
      // Retry network error or 5xx errors
      if ((error instanceof Error429 || error instanceof Error5xx) && tries > 0) {
        console.error(`Retry Response status: ${error.message}`);
        // if the rate limit is reached or exceeded, the system will have to obey to a 5 second cooldown period before attempting the API requests again.
        const delay = 5100;
        return wait(delay).then(() => fetchWithRetry(url, init, tries - 1));
      } else {
        console.error(error);
        throw error;
      }
    });

class ParkPowApi {
  constructor(token, sdkUrl = null) {
    if (token === null) {
      throw new Error("ParkPow TOKEN is required if using Cloud API");
    } else {
      this.token = token;
    }
    if (sdkUrl) {
      this.apiBase = `${sdkUrl}/api/v1/`;
    } else {
      this.apiBase = "https://app.parkpow.com/api/v1/";
    }
    console.debug(`Api Base: ${this.apiBase}`);
  }

  async logVehicle(encodedImage, licensePlateNumber, confidence, camera, timestamp) {
    const endpoint = "log-vehicle/";
    const pTime = new Date(timestamp * 1000).toISOString();
    const data = {
      camera: camera,
      image: encodedImage,
      results: [
        {
          plate: licensePlateNumber,
          score: confidence,
          // box: { xmin: 0, ymin: 0, ymax: 0, xmax: 0 },
        },
      ],
      time: pTime,
    };
    const init = {
      body: JSON.stringify(data),
      method: "POST",
      headers: {
        "Content-type": "application/json",
        Authorization: `Token ${this.token}`,
      },
    };
    const url = this.apiBase + endpoint;
    return fetchWithRetry(url, init, 5).then((response) => response.json());
  }
}
class VerkadaApi {
  constructor(apiKey) {
    this.apiKey = apiKey;
  }

  static async downloadImage(url) {
    return fetchWithRetry(url, {}).then(async (res) => {
      const buffer = await res.arrayBuffer();
      return Buffer.from(buffer).toString("base64");
    });
  }

  async getSeenLicensePlateImage(cameraId, timestamp, plate) {
    const params = {
      page_size: 5,
      camera_id: cameraId,
      license_plate: plate,
      start_time: timestamp - 1,
      end_time: timestamp + 1,
    };
    const endpoint = "https://api.verkada.com/cameras/v1/analytics/lpr/images";
    const init = {
      headers: {
        accept: "application/json",
        "x-api-key": this.apiKey,
      },
    };
    const url = `${endpoint}?${new URLSearchParams(params)}`;
    console.log(`LPR Images url : ${url}`);
    return fetchWithRetry(url, init).then(async (res) => {
      const data = await res.json();
      console.log(`Data: ${JSON.stringify(data)}`);
      for (const detection of data.detections) {
        if (detection.timestamp === timestamp && detection.license_plate === plate) {
          return detection.image_url;
        }
      }
      return Promise.reject("Detection not found");
    });
  }
}

async function processWebhook(data, verkada, parkpow, rollbar) {
  const cameraId = data.camera_id;
  const createdAt = data.created;
  const confidence = data.confidence;
  const licensePlateNumber = data.license_plate_number;

  return verkada
    .getSeenLicensePlateImage(cameraId, createdAt, licensePlateNumber)
    .then((imageUrl) => {
      console.log(`Download Image from URL: ${imageUrl}`);
      return VerkadaApi.downloadImage(imageUrl);
    })
    .then((imageBase64) => {
      console.log("Log vehicle");
      return parkpow.logVehicle(
        imageBase64,
        licensePlateNumber,
        confidence,
        cameraId,
        createdAt,
      );
    })
    .catch(async (error) => {
      // Log exceptions and re-throw
      await rollbar.error(error, "Verkada-lpr-webhooks");
      throw error;
    });
}

export default {
  // Our fetch handler is invoked on a HTTP request: we can send a message to a queue
  // during (or after) a request.
  // https://developers.cloudflare.com/queues/platform/javascript-apis/#producer
  async fetch(request, env, _ctx) {
    if (request.method === "POST") {
      const contentType = request.headers.get("content-type");
      if (contentType.includes("application/json")) {
        const data = await request.json();
        const webhookType = data.webhook_type;
        if (webhookType !== "lpr") {
          return new Response(`Unexpected webhook type: ${webhookType}`, {
            status: 400,
          });
        }
        await env.LPR_WEBHOOKS.send(data);
        return new Response("OK!");
      } else {
        return new Response("Error - Required application/json ", {
          status: 400,
        });
      }
    } else {
      return new Response("Error - Required POST", { status: 400 });
    }
  },

  // The queue handler is invoked when a batch of messages is ready to be delivered
  // https://developers.cloudflare.com/queues/platform/javascript-apis/#messagebatch
  async queue(batch, env) {
    const verkada = new VerkadaApi(env.VERKADA_API_KEY);
    const parkpow = new ParkPowApi(env.PARKPOW_TOKEN, env.PARKPOW_URL);
    const rollbar = new Rollbar(env.ROLLBAR_TOKEN, "production");

    // A queue consumer can make requests to other endpoints on the Internet,
    // write to R2 object storage, query a D1 Database, and much more.
    for (const message of batch.messages) {
      // Process each message (we'll just log these)
      console.log(`Message: ${JSON.stringify(message.body)}`);
      const data = message.body.data;
      const result = await processWebhook(data, verkada, parkpow, rollbar);
      console.info(`Logged Vehicle: ${JSON.stringify(result)}`);
      // Explicitly acknowledge the message as delivered
      message.ack();
    }
  },
};
